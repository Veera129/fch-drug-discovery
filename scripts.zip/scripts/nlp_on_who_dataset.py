#!/usr/bin/env python
# coding: utf-8

# In[250]:


import csv
import pandas as pd
import numpy as np
# using natural language toolkit
import nltk
# Filter out Stop Words (and Pipeline) like “the“, “a“, and “is“.
from nltk.corpus import stopwords
stop_words = stopwords.words('english')
import sys
RED   = "\033[1;31m"  
BLUE  = "\033[1;34m"
GREEN = "\033[0;32m"
CYAN  = "\033[1;36m"


# In[216]:


df=pd.read_table("C:/Users/pnavemoh/Desktop/covid-19/researchpaper/who_db_apr9.csv", sep=",")


# In[217]:


df.count()


# In[218]:


df.head(3)


# In[219]:


abs_count = len(df['Abstract']) 
abs_count


# In[220]:


df['Abstract'][0]


# In[221]:


# function to get unique values 
def unique(list1): 
  
    # intilize a null list 
    unique_list = [] 
      
    # traverse for all elements 
    for x in list1: 
        # check if exists in unique_list or not 
        if x not in unique_list: 
            unique_list.append(x) 
    # print list 
    for x in unique_list: 
        print (x + ",")
    return unique_list


# In[222]:


#remove whitespaces from words
import re
def remove_punct(text):
    new_words = []
    for word in text:
        w = re.sub(r'[^\w\s]','',word) #remove everything except words and space and also to remove underscore as well
        w = re.sub(r'\_','',w)
        new_words.append(w)
    return new_words


# In[261]:


def get_statement(sentence, check_word):
    sentence, checkword = sentence, check_word
    string_len = len(sentence) - 1  
    brief_txt = ''
    if checkword in sentence:
        for i, j in enumerate(sentence):
            if j == checkword:
                balance_idx = string_len - i  
                try:
                    if (i < 2) and (balance_idx > 0):
                        brief_txt = sentence[i] + " " + sentence[i+1]      
                except:
                    pass
                try:
                    if (i < 2) and (balance_idx > 1):
                        brief_txt = sentence[i] + " " + sentence[i+1] + " " + sentence[i+2]       
                except:
                    pass
                try:
                    if (i < 2) and (balance_idx > 2):
                        brief_txt = sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3]       
                except:
                    pass
                try:
                    if (i < 2) and (balance_idx > 3):
                        brief_txt = sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4]        
                except:
                    pass
                try:
                    if (i < 2) and (balance_idx > 4):
                        brief_txt = sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4] + " " + sentence[i+5]        
                except:
                    pass
                try:
                    if (i < 2) and (balance_idx > 5):
                        brief_txt = sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4] + " " + sentence[i+5] + " " + sentence[i+6]      
                except:
                    pass
                try:
                    if (i < 2) and (balance_idx > 6):
                        brief_txt = sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4] + " " + sentence[i+5] + " " + sentence[i+6] + " " + sentence[i+7]        
                except:
                    pass
                try:
                    if (i < 2) and (balance_idx > 7):
                        brief_txt = sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4] + " " + sentence[i+5] + " " + sentence[i+6] + " " + sentence[i+7] + " " + sentence[i+8]        
                except:
                    pass
                try:
                    if (i < 2) and (balance_idx > 8):
                        brief_txt = sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4] + " " + sentence[i+5] + " " + sentence[i+6] + " " + sentence[i+7] + " " + sentence[i+8] + " " + sentence[i+9]        
                except:
                    pass
                try:
                    if (i < 2) and (balance_idx > 9):
                        brief_txt = sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4] + " " + sentence[i+5] + " " + sentence[i+6] + " " + sentence[i+7] + " " + sentence[i+8] + " " + sentence[i+9] + " " + sentence[i+10]         
                except:
                    pass
                try:
                    if (i >= 2) and (balance_idx > 0):
                        brief_txt = sentence[i-2] + " " + sentence[i-1] + " " + sentence[i] + " " + sentence[i+1]       
                except:
                    pass
                try:
                    if (i >= 2) and (balance_idx > 1):
                        brief_txt = sentence[i-2] + " " + sentence[i-1] + " " + sentence[i] + " " + sentence[i+1] + " " + sentence[i+2]       
                except:
                    pass
                try:
                    if (i >= 2) and (balance_idx > 2):
                        brief_txt = sentence[i-2] + " " + sentence[i-1] + " " + sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3]       
                except:
                    pass
                try:
                    if (i >= 2) and (balance_idx > 3):
                        brief_txt = sentence[i-2] + " " + sentence[i-1] + " " + sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4]        
                except:
                    pass
                try:
                    if (i >= 2) and (balance_idx > 4):
                        brief_txt = sentence[i-2] + " " + sentence[i-1] + " " + sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4] + " " + sentence[i+5]        
                except:
                    pass
                try:
                    if (i >= 2) and (balance_idx > 5):
                        brief_txt = sentence[i-2] + " " + sentence[i-1] + " " + sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4] + " " + sentence[i+5] + " " + sentence[i+6]      
                except:
                    pass
                try:
                    if (i >= 2) and (balance_idx > 6):
                        brief_txt = sentence[i-2] + " " + sentence[i-1] + " " + sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4] + " " + sentence[i+5] + " " + sentence[i+6] + " " + sentence[i+7]        
                except:
                    pass
                try:
                    if (i >= 2) and (balance_idx > 7):
                        brief_txt = sentence[i-2] + " " + sentence[i-1] + " " + sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4] + " " + sentence[i+5] + " " + sentence[i+6] + " " + sentence[i+7] + " " + sentence[i+8]        
                except:
                    pass
                try:
                    if (i >= 2) and (balance_idx > 8):
                        brief_txt = sentence[i-2] + " " + sentence[i-1] + " " + sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4] + " " + sentence[i+5] + " " + sentence[i+6] + " " + sentence[i+7] + " " + sentence[i+8] + " " + sentence[i+9]        
                except:
                    pass
                try:
                    if (i >= 2) and (balance_idx > 9):
                        brief_txt = sentence[i-2] + " " + sentence[i-1] + " " + sentence[i] + " " + sentence[i+1] + " " + sentence[i+2] + " " + sentence[i+3] + " " + sentence[i+4] + " " + sentence[i+5] + " " + sentence[i+6] + " " + sentence[i+7] + " " + sentence[i+8] + " " + sentence[i+9] + " " + sentence[i+10]       
                except:
                    pass
                
                print(":: ", brief_txt)

    return brief_txt


# In[224]:


#preprocessing words from asbtract
cnt = 0
list_words = []
all_words = []

while (cnt < abs_count):    
    txt = str(df['Abstract'][cnt])
    txt = txt.lower() # convert to lowercase
    if (len(txt) > 5): #just putting logic to ensure have useful info
        txt2 = txt.split() # get word and convert into list
        words = [w for w in txt2 if not w in stop_words]
        uniq_words = unique(words) # unique words
        clean_word = remove_punct(uniq_words)
        for every_word in clean_word:
            list_words.append(every_word)
        if not clean_word in all_words:
            all_words.append(clean_word)    #keeping into array
            print(clean_word)
    cnt += 1

    


# In[225]:


drug_list = ['abacavir', 'abarelix', 'abatacept', 'abciximab', 'abiraterone', 'acamprosate', 'acarbose', 'acebutolol', 
             'acenocoumarol', 'acepromazine', 'aceprometazine', 'acetaminophen', 'acetazolamide', 'acetic acid', 
             'acetohexamide', 'acetohydroxamic acid', 'acetophenazine', 'acetylcysteine', 'acetyldigitoxin', 
             'acetylsalicylic acid', 'acitretin', 'aclidinium', 'acyclovir', 'adalimumab', 'adapalene', 'adefovir dipivoxil', 
             'adenine', 'adenosine', 'adenosine monophosphate', 'adenosine triphosphate', 'adinazolam', 
             'ado-trastuzumab emtansine', 'afatinib', 'aflibercept', 'agalsidase beta', 'agomelatine', 
             'ajmaline', 'albendazole', 'alcaftadine', 'alclometasone', 'aldesleukin', 'alefacept', 
             'alemtuzumab', 'alendronate', 'alfacalcidol', 'alfentanil', 'alfuzosin', 'alglucerase', 
             'alglucosidase alfa', 'aliskiren', 'alitretinoin', 'alizapride', 'allopurinol', 'allylestrenol', 'almitrine', 'almotriptan', 'alogliptin', 'alosetron', 'alpha-1-proteinase inhibitor', 'alpha-linolenic acid', 'alprazolam', 'alprenolol', 'alprostadil', 'alseroxylon', 'alteplase', 'altretamine', 'aluminium', 'aluminum hydroxide', 'alverine', 'alvimopan', 'amantadine', 'ambenonium', 'amcinonide', 'amdinocillin', 'amifostine', 'amikacin', 'amiloride', 'aminocaproic acid', 'aminoglutethimide', 'aminohippurate', 'aminolevulinic acid', 'aminophenazone', 'aminophylline', 'aminosalicylic acid', 'amiodarone', 'amisulpride', 'amitriptyline', 'amlexanox', 'amlodipine', 'ammonium lactate', 'amobarbital', 'amodiaquine', 'amoxapine', 'amoxicillin', 'amphetamine', 'amphotericin b', 'ampicillin', 'amprenavir', 'amrinone', 'amsacrine', 'amyl nitrite', 'anagrelide', 'anakinra', 'anastrozole', 'anidulafungin', 'anileridine', 'anisindione', 'anisotropine methylbromide', 'anistreplase', 'antazoline', 'antihemophilic factor', 'antipyrine', 'antithymocyte globulin', 'antrafenine', 'apixaban', 'apomorphine', 'apraclonidine', 'aprepitant', 'aprindine', 'aprobarbital', 'aprotinin', 'arbekacin', 'arbutamine', 'arcitumomab', 'ardeparin', 'arformoterol', 'argatroban', 'aripiprazole', 'arsenic trioxide', 'artemether', 'asenapine', 'asparaginase', 'asparaginase erwinia chrysanthemi', 'aspartame', 'astemizole', 'atazanavir', 'atenolol', 'atomoxetine', 'atorvastatin', 'atovaquone', 'atracurium', 'atropine', 'attapulgite', 'auranofin', 'avanafil', 'axitinib', 'azacitidine', 'azatadine', 'azathioprine', 'azelaic acid', 'azelastine', 'azidocillin', 'azilsartan medoxomil', 'azithromycin', 'azlocillin', 'aztreonam', 'bacampicillin', 'bacitracin', 'baclofen', 
             'balsalazide', 'bambuterol', 'basiliximab', 'becaplermin', 'beclometasone dipropionate', 'bedaquiline', 'belatacept', 'belimumab', 'benazepril', 'bendroflumethiazide', 'bentiromide', 'bentoquatam', 'benzatropine', 'benzocaine', 'benzonatate', 'benzphetamine', 'benzquinamide', 'benzthiazide', 'benzyl alcohol', 'benzyl benzoate', 'benzylpenicilloyl polylysine', 'bepotastine', 'bepridil', 'besifloxacin', 'betahistine', 'betamethasone', 'betaxolol', 'betazole', 'bethanechol', 'bethanidine', 'bevacizumab', 'bevantolol', 'bexarotene', 'bezafibrate', 'bicalutamide', 'bifonazole', 'bimatoprost', 'biotin', 'biperiden', 'bismuth subsalicylate', 'bisoprolol', 'bivalirudin', 'bleomycin', 'boceprevir', 'bopindolol', 'bortezomib', 'bosentan', 'bosutinib', 'botulinum toxin type a', 'botulinum toxin type b', 'brentuximab vedotin', 'bretylium', 'brimonidine', 'brinzolamide', 'bromazepam', 'bromfenac', 'bromocriptine', 'bromodiphenhydramine', 'brompheniramine', 'buclizine', 'budesonide', 'bumetanide', 'bupivacaine', 'bupranolol', 'buprenorphine', 'bupropion', 'buserelin', 'buspirone', 'busulfan', 'butabarbital', 'butalbital', 'butenafine', 'butethal', 'butoconazole', 'butorphanol', 'cabazitaxel', 'cabergoline', 'cabozantinib', 'caffeine', 'calcidiol', 'calcipotriol', 'calcitriol', 'calcium acetate', 'calcium carbonate', 'calcium chloride', 'calcium gluceptate', 'camazepam', 'canagliflozin', 'canakinumab', 'candesartan', 'candicidin', 'candoxatril', 'capecitabine', 'capreomycin', 'capromab', 'captopril', 'carbachol', 'carbamazepine', 'carbenicillin', 'carbetocin', 'carbidopa', 'carbimazole', 'carbinoxamine', 'carboplatin', 'carboprost tromethamine', 'carfilzomib', 'carglumic acid', 'carisoprodol', 'carmustine', 'carphenazine', 'carprofen', 'carteolol', 'carvedilol', 'caspofungin', 'cefacetrile', 'cefaclor', 'cefadroxil', 'cefalotin', 'cefamandole', 'cefazolin', 'cefdinir', 'cefditoren', 'cefepime', 'cefixime', 'cefmenoxime', 'cefmetazole', 'cefonicid', 'cefoperazone', 'ceforanide', 'cefotaxime', 'cefotetan', 'cefotiam', 'cefoxitin', 'cefpiramide', 'cefpodoxime', 'cefprozil', 'cefradine', 'ceftaroline fosamil', 'ceftazidime', 'ceftibuten', 'ceftizoxime', 'ceftriaxone', 'cefuroxime', 'celecoxib', 'cephalexin', 'cephaloglycin', 'cephapirin', 'certolizumab pegol', 'cerulenin', 'ceruletide', 'cetirizine', 'cetrorelix', 'cetuximab', 'cevimeline', 'chenodeoxycholic acid', 'chlophedianol', 'chlorambucil', 'chloramphenicol', 'chlordiazepoxide', 'chlorhexidine', 'chlormerodrin', 'chlormezanone', 'chloroprocaine', 'chloropyramine', 'chloroquine', 'chlorothiazide', 'chlorotrianisene', 'chloroxine', 'chlorphenesin', 'chlorpheniramine', 'chlorpromazine', 'chlorpropamide', 'chlorprothixene', 'chlorthalidone', 'chlorzoxazone', 'cholecalciferol', 'cholestyramine', 'choline', 'choriogonadotropin alfa', 'ciclesonide', 'ciclopirox', 'cidofovir', 'cilastatin', 'cilazapril', 'cilostazol', 'cimetidine', 'cinacalcet', 'cinalukast', 'cinitapride', 'cinnarizine', 'cinolazepam', 'cinoxacin', 'ciprofloxacin', 'cisapride', 'cisatracurium besylate', 'cisplatin', 'citalopram', 'cladribine', 'clarithromycin', 'clavulanate', 'clemastine', 'clenbuterol', 'clevidipine', 'clidinium', 'clindamycin', 'clobazam', 'clobetasol', 'clocortolone', 'clodronate', 'clofarabine', 'clofazimine', 'clofibrate', 'clomifene', 'clomipramine', 'clomocycline', 'clonazepam', 'clonidine', 'clopidogrel', 'clorazepate', 'clotiazepam', 'clotrimazole', 'cloxacillin', 'cloxazolam', 'clozapine', 'coagulation factor ix', 'coagulation factor viia', 'cocaine', 'codeine', 'colchicine', 'colesevelam', 'colestipol', 'colistimethate', 'colistin', 'collagenase', 'conivaptan', 'conjugated estrogens', 'corticotropin', 'cortisone acetate', 'cosyntropin', 'creatine', 'crofelemer', 'cromoglicic acid', 'crotamiton', 'cryptenamine', 'cyanocobalamin', 'cyclacillin', 'cyclandelate', 'cyclizine', 'cyclobenzaprine', 'cyclopentolate', 'cyclophosphamide', 'cycloserine', 'cyclosporine', 'cyclothiazide', 'cycrimine', 'cyproheptadine', 'cyproterone', 'cysteamine', 'cytarabine', 'dabigatran etexilate', 'dabrafenib', 'dacarbazine', 'daclizumab', 'dactinomycin', 'dalfampridine', 'dalfopristin', 'dalteparin', 'danazol', 'dantrolene', 'dapiprazole', 'dapsone', 'daptomycin', 'darbepoetin alfa', 'darifenacin', 'darunavir', 'dasatinib', 'daunorubicin', 'debrisoquin', 'decamethonium', 'decitabine', 'deferasirox', 'deferiprone', 'deferoxamine', 'defibrotide', 'degarelix', 'delavirdine', 'delorazepam', 'demecarium', 'demeclocycline', 'denileukin diftitox', 'denosumab', 'deserpidine', 'desflurane', 'desipramine', 'deslanoside', 'desloratadine', 'desmopressin', 'desogestrel', 'desonide', 'desoximetasone', 'desvenlafaxine', 'dexamethasone', 'dexbrompheniramine', 'dexfenfluramine', 'dexmedetomidine', 'dexmethylphenidate', 'dexrazoxane', 'dextroamphetamine', 'dextromethorphan', 'dextrothyroxine', 'dezocine', 'diatrizoate', 'diazepam', 'diazoxide', 'dibucaine', 'dichlorphenamide', 'diclofenac', 'dicloxacillin', 'dicumarol', 'dicyclomine', 'didanosine', 'dienestrol', 'diethylcarbamazine', 'diethylpropion', 'diethylstilbestrol', 'difenoxin', 'diflorasone', 'diflunisal', 'difluprednate', 'digitoxin', 'digoxin', 'digoxin immune fab', 'dihydrocodeine', 'dihydroergotamine', 'dihydroergotoxine', 'dihydrotachysterol', 'dihydroxyaluminium', 'diloxanide', 'diltiazem', 'dimenhydrinate', 'dimercaprol', 'dimethindene', 'dimethyl fumarate', 'dimethyl sulfoxide', 'dinoprost tromethamine', 'dinoprostone', 'diphemanil methylsulfate', 'diphenhydramine', 'diphenidol', 'diphenoxylate', 'diphenylpyraline', 'dipivefrin', 'dipyridamole', 'dirithromycin', 'disopyramide', 'disulfiram', 'dobutamine', 'docetaxel', 'docosanol', 'dofetilide', 'dolasetron', 'domperidone', 'donepezil', 'dopamine', 'dornase alfa', 'dorzolamide', 'doxacurium chloride', 'doxapram', 'doxazosin', 'doxepin', 'doxorubicin', 'doxycycline', 'doxylamine', 'dronabinol', 'dronedarone', 'droperidol', 'drospirenone', 'drostanolone', 'drotaverine', 'drotrecogin alfa', 'droxidopa', 'duloxetine', 'dutasteride', 'dyclonine', 'dydrogesterone', 'dyphylline', 'ecabet', 'echothiophate', 'econazole', 'eculizumab', 'edetic acid', 'edrophonium', 'efalizumab', 'efavirenz', 'eletriptan', 'eltrombopag', 'emedastine', 'emtricitabine', 'enalapril', 'encainide', 'enflurane', 'enfuvirtide', 'enoxacin', 'enoxaparin', 'enoximone', 'enprofylline', 'entacapone', 'entecavir', 'enzalutamide', 'ephedra', 'ephedrine', 'epinastine', 'epinephrine', 'epirubicin', 'eplerenone', 'epoetin alfa', 'epoprostenol', 'eprosartan', 'eptifibatide', 'ergocalciferol', 'ergoloid mesylate', 'ergonovine', 'ergotamine', 'eribulin', 'erlotinib', 'ertapenem', 'erythrityl tetranitrate', 'erythromycin', 'escitalopram', 'esmolol', 'esomeprazole', 'estazolam', 'estradiol', 'estradiol valerate/dienogest', 'estramustine', 'estriol', 'estrone', 'estropipate', 'eszopiclone', 'etanercept', 'ethacrynic acid', 'ethambutol', 'ethanol', 'ethanolamine oleate', 'ethchlorvynol', 'ethinamate', 'ethinyl estradiol', 'ethiodized oil', 'ethionamide', 'ethopropazine', 'ethosuximide', 'ethotoin', 'ethoxzolamide', 'ethylmorphine', 'ethynodiol diacetate', 'etidronic acid', 'etodolac', 'etomidate', 'etonogestrel', 'etoposide', 'etoricoxib', 'everolimus', 'exemestane', 'exenatide', 'ezetimibe', 'ezogabine', 'famciclovir', 'famotidine', 'felbamate', 'felodipine', 'felypressin', 'fencamfamine', 'fenofibrate', 'fenoldopam', 'fenoprofen', 'fenoterol', 'fentanyl', 'ferric carboxymaltose', 'fesoterodine', 'fexofenadine', 'fidaxomicin', 'filgrastim', 'finasteride', 'fingolimod', 'flavoxate', 'flecainide', 'fleroxacin', 'floxuridine', 'flucloxacillin', 'fluconazole', 'flucytosine', 'fludarabine', 'fludiazepam', 'fludrocortisone', 'flumazenil', 'flumethasone pivalate', 'flunarizine', 'flunisolide', 'flunitrazepam', 'fluocinolone acetonide', 'fluocinonide', 'fluorescein', 'fluorometholone', 'fluorouracil', 'fluoxetine', 'fluoxymesterone', 'flupenthixol', 'fluphenazine', 'flurandrenolide', 'flurazepam', 'flurbiprofen', 'fluspirilene', 'flutamide', 
             'fluticasone furoate', 'fluticasone propionate', 'fluvastatin', 'fluvoxamine', 'folic acid', 'follitropin beta', 'fomepizole', 'fondaparinux sodium', 'forasartan', 'formestane', 'formoterol', 'fosamprenavir', 'fosaprepitant', 'foscarnet', 'fosfomycin', 'fosinopril', 'fosphenytoin', 'fospropofol', 'framycetin', 'frovatriptan', 'fulvestrant', 'furazolidone', 'furosemide', 'fusidic acid', 'gabapentin', 'gabapentin enacarbil', 'gadobenate dimeglumine', 'gadobutrol', 'gadodiamide', 'gadofosveset trisodium', 'gadopentetate dimeglumine', 'gadoteridol', 'gadoversetamide', 'gadoxetate', 'galantamine', 'gallamine triethiodide', 'gallium nitrate', 'galsulfase', 'gamma-homolinolenic acid', 'gamma hydroxybutyric acid', 'ganciclovir', 'gatifloxacin', 'gefitinib', 'gemcitabine', 'gemfibrozil', 'gemifloxacin', 'gemtuzumab ozogamicin', 'gentamicin', 'gentian violet', 'gestodene', 'ginkgo biloba', 'ginseng', 'glatiramer acetate', 'gliclazide', 'glimepiride', 'glipizide', 'gliquidone', 'glisoxepide', 'glucagon recombinant', 'glucarpidase', 'glucosamine', 'glutathione', 'glutethimide', 'glyburide', 'glycerol phenylbutyrate', 'glycine', 'glycodiazine', 'glycopyrrolate', 'golimumab', 'gonadorelin', 'goserelin', 'gramicidin d', 'granisetron', 'grepafloxacin', 'griseofulvin', 'guaifenesin', 'guanabenz', 'guanadrel sulfate', 'guanethidine', 'guanfacine', 'guanidine', 'halazepam', 'halobetasol propionate', 'halofantrine', 'haloperidol', 'haloprogin', 'halothane', 'heparin', 'heptabarbital', 'heroin', 'hesperetin', 'hetacillin', 'hexachlorophene', 'hexafluronium', 'hexobarbital', 'hexylcaine', 'histamine phosphate', 'homatropine methylbromide', 'homoharringtonine', 'human serum albumin', 'hyaluronan', 'hyaluronidase', 'hydralazine', 'hydrochlorothiazide', 'hydrocodone', 'hydrocortamate', 'hydrocortisone', 'hydroflumethiazide', 'hydromorphone', 'hydroxocobalamin', 'hydroxychloroquine', 'hydroxyproline', 'hydroxypropyl cellulose', 'hydroxystilbamidine isethionate', 'hydroxyurea', 'hydroxyzine', 'hyoscyamine', 'ibandronate', 'ibritumomab', 'ibudilast', 'ibuprofen', 'ibutilide', 'icatibant', 'icodextrin', 'icosapent', 'icosapent ethyl', 'idarubicin', 'idoxuridine', 'idursulfase', 'ifosfamide', 'iloperidone', 'iloprost', 'imatinib', 'imiglucerase', 'imipenem', 'imipramine', 'imiquimod', 'indacaterol', 'indapamide', 'indecainide', 'indinavir', 'indomethacin', 'infliximab', 'ingenol mebutate', 'insulin aspart', 'insulin detemir', 'insulin glargine', 'insulin glulisine', 'insulin lispro', 'insulin regular', 'insulin, isophane', 'insulin, porcine', 'interferon alfa-2a, recombinant', 'interferon alfa-2b, recombinant', 'interferon alfa-n1', 'interferon alfa-n3', 'interferon alfacon-1', 'interferon beta-1a', 'interferon beta-1b', 'interferon gamma-1b', 'intravenous immunoglobulin', 'inulin', 'iobenguane', 'iodipamide', 'iodixanol', 'ioflupane i 123', 'iohexol', 'iophendylate', 'ipratropium bromide', 'irbesartan', 'irinotecan', 'iron', 'iron dextran', 'isocarboxazid', 'isoetharine', 'isoflurane', 'isoflurophate', 'isometheptene', 'isoniazid', 'isopropamide', 'isoproterenol', 'isosorbide dinitrate', 'isosorbide mononitrate', 'isothipendyl', 'isotretinoin', 'isradipine', 'itraconazole', 'ivacaftor', 'ivermectin', 'ixabepilone', 'josamycin', 'kanamycin', 'kaolin', 'ketamine', 'ketazolam', 'ketoconazole', 'ketoprofen', 'ketorolac', 'ketotifen', 'kunecatechins', 'l-alanine', 'l-arginine', 'l-asparagine', 'l-aspartic acid', 'l-carnitine', 'l-citrulline', 'l-cysteine', 'l-cystine', 'l-glutamic acid', 'l-glutamine', 'l-histidine', 'l-isoleucine', 'l-leucine', 'l-lysine', 'l-methionine', 'l-ornithine', 'l-phenylalanine', 'l-proline', 'l-serine', 'l-threonine', 'l-tryptophan', 'l-tyrosine', 'l-valine', 'labetalol', 'lacosamide', 'lactulose', 'lamivudine', 'lamotrigine', 'lansoprazole', 'lapatinib', 'laronidase', 'latamoxef', 'latanoprost', 'leflunomide', 'lenalidomide', 'lepirudin', 'lercanidipine', 'letrozole', 'leucovorin', 'leuprolide', 'levallorphan', 'levamisole', 'levetiracetam', 'levobunolol', 'levobupivacaine', 'levocabastine', 'levodopa', 'levofloxacin', 'levomethadyl acetate', 'levomilnacipran', 'levonordefrin', 'levonorgestrel', 'levorphanol', 'levosimendan', 'levothyroxine', 'lidocaine', 'linaclotide', 'linagliptin', 'lincomycin', 'lindane', 'linezolid', 'liothyronine', 'liotrix', 'lipoic acid', 'liraglutide', 'lisdexamfetamine', 'lisinopril', 'lisuride', 'lithium', 'lofexidine', 'lomefloxacin', 'lomitapide', 'lomustine', 'loperamide', 'lopinavir', 'loracarbef', 'loratadine', 'lorazepam', 'lorcaserin', 'lornoxicam', 'losartan', 'loteprednol', 'lovastatin', 'loxapine', 'lubiprostone', 'lucanthone', 'lucinactant', 'lumefantrine', 'lumiracoxib', 'lurasidone', 'lutropin alfa', 'lymecycline', 'magnesium oxide', 'magnesium salicylate', 'magnesium sulfate', 'malathion', 'mannitol', 'maprotiline', 'maraviroc', 'marimastat', 'masoprocol', 'mazindol', 'mebendazole', 'mecamylamine', 'mecasermin', 'mechlorethamine', 'meclizine', 'meclofenamic acid', 'medroxyprogesterone', 'medrysone', 'mefenamic acid', 'mefloquine', 'megestrol', 'melatonin', 'meloxicam', 'melphalan', 'memantine', 'menadione', 'menotropins', 'menthol', 'mepenzolate', 'meperidine', 'mephentermine', 'mephenytoin', 'mepivacaine', 'meprobamate', 'mepyramine', 'mequitazine', 'mercaptopurine', 'meropenem', 'mesalazine', 'mesoridazine', 'mestranol', 'metaraminol', 'metaxalone', 'metformin', 'methacholine', 'methacycline', 'methadone', 'methadyl acetate', 'methamphetamine', 'methantheline', 'metharbital', 'methazolamide', 'methdilazine', 'methimazole', 'methocarbamol', 'methohexital', 'methotrexate', 'methotrimeprazine', 'methoxamine', 'methoxsalen', 'methoxyflurane', 'methsuximide', 'methyclothiazide', 'methyl aminolevulinate', 'methyldopa', 'methylergonovine', 'methylnaltrexone', 'methylphenidate', 'methylphenobarbital', 'methylprednisolone', 'methylscopolamine', 'methyltestosterone', 'methyprylon', 'methysergide', 'meticillin', 'metipranolol', 'metixene', 'metoclopramide', 'metocurine', 'metocurine iodide', 'metolazone', 'metoprolol', 'metrizamide', 'metronidazole', 'metyrapone', 'metyrosine', 'mexiletine', 'mezlocillin', 'mianserin', 'micafungin', 'miconazole', 'midazolam', 'midodrine', 'mifepristone', 'miglitol', 'miglustat', 'milnacipran', 'milrinone', 'mimosine', 'minaprine', 'minocycline', 'minoxidil', 'mipomersen', 'mirabegron', 'mirtazapine', 'misoprostol', 'mitiglinide', 'mitomycin', 'mitotane', 'mitoxantrone', 'mivacurium', 'moclobemide', 'modafinil', 'moexipril', 'molindone', 'mometasone', 'monobenzone', 'montelukast', 'moricizine', 'morphine', 'moxifloxacin', 'mupirocin', 'muromonab', 'mycophenolate mofetil', 'mycophenolic acid', 'n-acetyl-d-glucosamine', 'nabilone', 'nabumetone', 'nadh', 'nadolol', 'nadroparin', 'nafarelin', 'nafcillin', 'naftifine', 'nalbuphine', 'nalidixic acid', 'naloxone', 'naltrexone', 'nandrolone decanoate', 'nandrolone phenpropionate', 'naphazoline', 'naproxen', 'naratriptan', 'natalizumab', 'natamycin', 'nateglinide', 'nebivolol', 'nedocromil', 'nefazodone', 'nelarabine', 'nelfinavir', 'neomycin', 'neostigmine', 'nepafenac', 'nesiritide', 'netilmicin', 'nevirapine', 'niacin', 'nicardipine', 'nicergoline', 'niclosamide', 'nicotine', 'nifedipine', 'niflumic acid', 'nilotinib', 'nilutamide', 'nilvadipine', 'nimodipine', 'nisoldipine', 'nitazoxanide', 'nitisinone', 'nitrazepam', 'nitrendipine', 'nitric oxide', 'nitrofurantoin', 'nitrofurazone', 'nitroglycerin', 'nitroprusside', 'nitroxoline', 'nizatidine', 'nonoxynol-9', 'norelgestromin', 'norepinephrine', 'norethindrone', 'norfloxacin', 'norgestimate', 'nortriptyline', 'novobiocin', 'nystatin', 'ocriplasmin', 'octreotide', 'ofloxacin', 'olanzapine', 'olmesartan', 'olopatadine', 'olsalazine', 'omalizumab', 'omeprazole', 'ondansetron', 'oprelvekin', 'orciprenaline', 'orlistat', 'orphenadrine', 'oseltamivir', 'ospa lipoprotein', 'ospemifene', 'ouabain', 'oxacillin', 'oxaliplatin', 'oxamniquine', 'oxandrolone', 'oxaprozin', 'oxazepam', 'oxcarbazepine', 'oxiconazole', 'oxitriptan', 'oxprenolol', 'oxtriphylline', 'oxybenzone', 'oxybuprocaine', 'oxybutynin', 'oxycodone', 'oxymetazoline', 'oxymorphone', 'oxyphencyclimine', 'oxyphenonium', 'oxytetracycline', 'oxytocin', 'paclitaxel', 'palifermin', 'paliperidone', 'palivizumab', 'palonosetron', 'pamidronate', 'pancrelipase', 'pancuronium', 'panitumumab', 'pantoprazole', 'papaverine', 'paramethadione', 'paramethasone', 'pargyline', 'paricalcitol', 'paromomycin', 'paroxetine', 'pasireotide', 'pazopanib', 'pefloxacin', 'pegademase bovine', 'pegaptanib', 'pegaspargase', 'pegfilgrastim', 'peginesatide', 'peginterferon alfa-2a', 'peginterferon alfa-2b', 'pegvisomant', 'pemetrexed', 'pemirolast', 'penbutolol', 'penciclovir', 'penicillamine', 'penicillin g', 'penicillin v', 'pentagastrin', 'pentamidine', 'pentazocine', 'pentobarbital', 'pentolinium', 'pentosan polysulfate', 'pentostatin', 'pentoxifylline', 'perampanel', 'perflutren', 'pergolide', 'perhexiline', 'perindopril', 'permethrin', 'perphenazine', 'pertuzumab', 'phenacemide', 'phenazopyridine', 'phendimetrazine', 'phenelzine', 'phenformin', 'phenindamine', 'phenindione', 'pheniramine', 'phenmetrazine', 'phenobarbital', 'phenol', 'phenoxybenzamine', 'phenprocoumon', 'phensuximide', 'phentermine', 'phentolamine', 'phenylbutazone', 'phenylephrine', 'phenylpropanolamine', 'phenytoin', 'phosphatidylserine', 'physostigmine', 'phytonadione', 'picrotoxin', 'pilocarpine', 'pimecrolimus', 'pimozide', 'pindolol', 'pioglitazone', 'pipazethate', 'pipecuronium', 'piperacillin', 'piperazine', 'pipobroman', 'pipotiazine', 'pirbuterol', 'pirenzepine', 'piroxicam', 'pitavastatin', 'pivampicillin', 'pivmecillinam', 'plerixafor', 'plicamycin', 'podofilox', 'polidocanol', 'polymyxin b sulfate', 'polystyrene sulfonate', 'polythiazide', 'pomalidomide', 'ponatinib', 'porfimer', 'posaconazole', 'potassium chloride', 'potassium iodide', 'practolol', 'pralatrexate', 'pralidoxime', 'pramipexole', 'pramlintide', 'pranlukast', 'prasugrel', 'pravastatin', 'prazepam', 'praziquantel', 'prazosin', 'prednicarbate', 'prednisolone', 'prednisone', 'pregabalin', 'preotact', 'prilocaine', 'primaquine', 'primidone', 'probenecid', 'probucol', 'procainamide', 'procaine', 'procarbazine', 'procaterol', 'prochlorperazine', 'procyclidine', 'proflavine', 'progabide', 'progesterone', 'proguanil', 'promazine', 'promethazine', 'propafenone', 'propantheline', 'proparacaine', 'propericiazine', 'propiomazine', 'propofol', 'propoxyphene', 'propranolol', 'propylhexedrine', 'propylthiouracil', 'protriptyline', 'pseudoephedrine', 'pyrazinamide', 'pyridostigmine', 'pyridoxal', 'pyridoxine', 'pyrimethamine', 'pyruvic acid', 'quazepam', 'quetiapine', 'quinacrine', 'quinapril', 'quinestrol', 'quinethazone', 'quinidine', 'quinidine barbiturate', 'quinine', 'quinupristin', 'rabeprazole', 'radium ra 223 dichloride', 'raloxifene', 'raltitrexed', 'ramelteon', 'ramipril', 'ranibizumab', 'ranitidine', 'ranolazine', 'rasagiline', 'rasburicase', 'raxibacumab', 'reboxetine', 'regadenoson', 'regorafenib', 'remifentanil', 'remikiren', 'remoxipride', 'repaglinide', 'rescinnamine', 'reserpine', 'retapamulin', 'reteplase', 'ribavirin', 'riboflavin', 'ridogrel', 'rifabutin', 'rifampin', 'rifapentine', 'rifaximin', 'rilonacept', 'rilpivirine', 'riluzole', 'rimantadine', 'rimexolone', 'rimonabant', 'risedronate', 'risperidone', 'ritodrine', 'ritonavir', 'rituximab', 'rivaroxaban', 'rivastigmine', 'rizatriptan', 'rocuronium', 'roflumilast', 'rolitetracycline', 'romiplostim', 'ropinirole', 'ropivacaine', 'rosiglitazone', 'rosoxacin', 'rosuvastatin', 'rotigotine', 'roxatidine acetate', 'roxithromycin', 'rufinamide', 'ruxolitinib', 's-adenosylmethionine', 'salbutamol', 'salicyclic acid', 'salicylamide', 'salicylate-sodium', 'salmeterol', 'salmon calcitonin', 'salsalate', 'saprisartan', 'saquinavir', 'sargramostim', 'satumomab pendetide', 'saxagliptin', 'scopolamine', 'secobarbital', 'secretin', 'selegiline', 'selenium sulfide', 'sermorelin', 'sertaconazole', 'sertindole', 'sertraline', 'serum albumin', 'serum albumin iodonated', 'sevelamer', 'sevoflurane', 'sibutramine', 'sildenafil', 'silodosin', 'silver sulfadiazine', 'simvastatin', 'sirolimus', 'sitagliptin', 'sitaxentan', 'sodium bicarbonate', 'sodium lauryl sulfate', 'sodium stibogluconate', 'sodium tetradecyl sulfate', 'solifenacin', 'somatropin recombinant', 'sorafenib', 'sotalol', 'spaglumic acid', 'sparfloxacin', 'spectinomycin', 'spermine', 'spinosad', 'spirapril', 'spironolactone', 'stanozolol', 'stavudine', 'stepronin', 'streptokinase', 'streptomycin', 'streptozocin', 'succimer', 'succinic acid', 'succinylcholine', 'sucralfate', 'sufentanil', 'sulfacetamide', 'sulfacytine', 'sulfadiazine', 'sulfadimethoxine', 'sulfadoxine', 'sulfamerazine', 'sulfamethazine', 'sulfamethizole', 'sulfamethoxazole', 'sulfametopyrazine', 'sulfamoxole', 'sulfanilamide', 'sulfaphenazole', 'sulfapyridine', 'sulfasalazine', 'sulfathiazole', 'sulfinpyrazone', 'sulfisoxazole', 'sulfoxone', 'sulindac', 'sulodexide', 'sulpiride', 'sumatriptan', 'sunitinib', 'suprofen', 'suramin', 'tacrine', 'tacrolimus', 'tadalafil', 'tafluprost', 'talbutal', 'taliglucerase alfa', 'tamibarotene', 'tamoxifen', 'tamsulosin', 'tapentadol', 'tasosartan', 'tauroursodeoxycholic acid', 'tazarotene', 'tazobactam', 'teduglutide', 'teicoplanin', 'telaprevir', 'telavancin', 'telbivudine', 'telithromycin', 'telmisartan', 'temazepam', 'temozolomide', 'temsirolimus', 'tenecteplase', 'teniposide', 'tenofovir', 'tenoxicam', 'terazosin', 'terbinafine', 'terbutaline', 'terconazole', 'terfenadine', 'teriflunomide', 'teriparatide', 'terlipressin', 'tesamorelin', 'testolactone', 'testosterone', 'testosterone propionate', 'tetrabenazine', 'tetracycline', 'tetrahydrobiopterin', 'tetrahydrofolic acid', 'thalidomide', 'theobromine', 'theophylline', 'thiabendazole', 'thiamine', 'thiamylal', 'thiethylperazine', 'thioguanine', 'thiopental', 'thioproperazine', 'thioridazine', 'thiotepa', 'thiothixene', 'thymalfasin', 'thyroglobulin', 'thyrotropin alfa', 'tiagabine', 'tiaprofenic acid', 'ticagrelor', 'ticarcillin', 'ticlopidine', 'tigecycline', 'tiludronate', 'timolol', 'tinidazole', 'tinzaparin', 'tioconazole', 'tiotropium', 'tipranavir', 'tirofiban', 'tizanidine', 'tobramycin', 'tocainide', 'tocilizumab', 'tofisopam', 'tolazamide', 'tolazoline', 'tolbutamide', 'tolcapone', 'tolmetin', 'tolnaftate', 'tolterodine', 'tolvaptan', 'topiramate', 'topotecan', 'torasemide', 'toremifene', 'tositumomab', 'trabectedin', 'tramadol', 'trametinib', 'trandolapril', 'tranexamic acid', 'tranylcypromine', 'trastuzumab', 'travoprost', 'trazodone', 'treprostinil', 'tretinoin', 'triamcinolone', 'triamterene', 'triazolam', 'trichlormethiazide', 'tridihexethyl', 'trifluoperazine', 'triflupromazine', 'trifluridine', 'triflusal', 'trihexyphenidyl', 'trilostane', 'trimeprazine', 'trimethadione', 'trimethaphan', 'trimethobenzamide', 'trimethoprim', 'trimetrexate', 'trimipramine', 'trioxsalen', 'tripelennamine', 'triprolidine', 'trisalicylate-choline', 'troleandomycin', 'tropicamide', 'trospium', 'trovafloxacin', 'tubocurarine', 'tyloxapol', 'tymazoline', 'udenafil', 'uracil mustard', 'urofollitropin', 'urokinase', 'ursodeoxycholic acid', 'valaciclovir', 'valganciclovir', 'valproic acid', 'valrubicin', 'valsartan', 'vancomycin', 'vandetanib', 'vapreotide', 'vardenafil', 'varenicline', 'vasopressin', 'vecuronium', 'velaglucerase alfa', 'vemurafenib', 'venlafaxine', 'verapamil', 'verteporfin', 'vidarabine', 'vigabatrin', 'vilazodone', 'vildagliptin', 'vinblastine', 'vincristine', 'vindesine', 'vinorelbine', 'vismodegib', 'vitamin a', 'vitamin c', 'vitamin e', 'voacamine', 'voglibose', 'voriconazole', 'vorinostat', 'warfarin', 'xanthophyll', 'ximelagatran', 'xylometazoline', 'yohimbine', 'zafirlukast', 'zalcitabine', 'zaleplon', 'zanamivir', 'zidovudine', 'zileuton', 'zinc', 'ziprasidone', 'zoledronate', 'zolmitriptan', 'zolpidem', 'zonisamide', 'zopiclone', 'zuclopenthixol']


# In[226]:


len(drug_list)


# In[229]:


#count number words frequency
potential_drug = []
for i in drug_list:
    substring = i
    count = list_words.count(substring)
    if count > 10:
        print ("",i, ":", count)
        potential_drug.append(i)


# In[263]:


#get brief statement from the abstract related to the drug 
#this to give idea how those drugs placed in the array
for item in potential_drug:
    check = item
    sys.stdout.write(BLUE)
    print("\nDrug: ", check)
    for mystr in all_words:
        sentence = mystr
        sys.stdout.write(CYAN)
        mystatement = get_statement(sentence, check)

            


# In[ ]:




